#include <Wire.h>

// Default I2C address of the NTAG
uint8_t I2C_ADDR = 0x55; // This varies, default 0x55, but I've found 0x01 possible too

// Function that writes a single byte to the first page 
// of the unprotected user memory of the NTAG
bool WriteToNFC(uint8_t data) {
	uint8_t writeData[16]; // Prepares array for writing to whole (1st) page of NFC device
	memset(writeData,0,16); // Zeroes whole array
	writeData[0] = data;
	Wire.begin(); // Initializes I2C
	Wire.beginTransmission(I2C_ADDR); // Slave's I2C Address
	Wire.write(0x01); // First page I2C address (in hex)
	for (int i = 0; i < 16; i ++) {
		Wire.write(writeData[i]);
	}
	bool status = Wire.endTransmission();
	delay(4); // Enforced here to prevent risk of corruption during EEPROM programming
	return status;
}

// This function will read 16 bytes from the desired I2C register of the NTAG
void ReadNTAG(uint8_t *data, uint8_t I2C_REG) {
  Wire.begin(); // Initializes I2C
	Wire.beginTransmission(I2C_ADDR); // Slave's I2C Address
	Wire.write(I2C_REG); // I2C register address
	Wire.endTransmission(); // Ends write of desired register
	Wire.requestFrom(I2C_ADDR, 16); // We want 16 bytes!
	for (int byte = 0; byte < 16; byte++) {
		data[byte] = Wire.read(); // Iterate and read 16 bytes
	} 
	return; // Fin
}